import React from 'react'
import Header from './Header'

function Categories() {
  return (
    <div>
       <Header spotify={spotify} />
    </div>
  )
}

export default Categories
